# code

> Create your code

This app uses Node.js/Express/MongoDB with Google OAuth for authentication


# Install dependencies
npm install

# Run in development
npm run dev

# Run in production
npm start